package streams;

import java.io.InputStream;


public class Mapa {

	public static void main(String[] args) throws Exception {
		imprimirMapa("sample533.ts");
	}
	
	private static void imprimirMapa(String ts) throws Exception{
		InputStream input = getInputStream(ts);
		byte[] buffer = new byte[188];
		
		while(hayPaquete(input, buffer)){
			imprimirPaquete(buffer);
		}
		
		input.close();
	}
	
	private static void imprimirPaquete(byte[] buffer) {
		if(PaqueteEnSincronia(buffer[0])){
			System.out.println(". ");
		}else{
			imprimirPID(buffer);
		}
	}

	private static void imprimirPID(byte[] buffer) {
		int pid = pid(buffer);
		
		if(esPAT(pid)){
			System.out.println("* ");
		}else if(esNull(pid)){
			System.out.println("| ");
		}
	}

	private static boolean esNull(int pid) {
		return pid == 0x1fff;
	}

	private static boolean esPAT(int pid) {
		return pid == 0x0000;
	}

	private static int pid(byte[] buffer) {
		int pid = 0x0000;
		int maskPid = 0x1fff;
		int byte2pid = buffer[1]<<8;
		int byte3pid = buffer[2]<<0;		
		
		pid = pid | byte2pid;
		pid = pid | byte3pid;
		
		pid = pid & maskPid;
		
		return pid;
	}

	private static boolean PaqueteEnSincronia(byte b) {
		return b == 0x0047;
	}

	private static boolean hayPaquete(InputStream input, byte[] buffer) throws Exception {
		int bytes = 0;
		
		while (bytes < buffer.length) {
			int lastReaded = input.read(buffer, bytes, buffer.length - bytes);
			
			if (lastReaded == -1) {
				return false;
			}
			
			bytes = bytes + lastReaded;
		}
		
		return true;
	}

	private static InputStream getInputStream(String ts) throws Exception {        
        return Mapa.class.getClassLoader().getResourceAsStream(ts);    
    }

}
