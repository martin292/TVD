package streams;

public class LectorPAT {

	public static void main(String[] args) {
		// TODO 
	}

}
